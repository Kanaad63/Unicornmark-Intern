# Calorie-estimation-from-food-images-opencv
An ML model which is trained to recognise food images, calculate volume and estimate calorie content

## Problem
The problem can be simply stated as, given a set of food images with calibration object thumb with the food name and an unlabeled set of food images from the same group of food, identify food and estimate food volume and calories intake.

## Objectives
To detect food type using ML

To estimate food weight and calories of food

